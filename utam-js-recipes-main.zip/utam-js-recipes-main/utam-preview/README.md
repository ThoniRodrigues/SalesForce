# utam-preview

Temporary package with Salesforce specific Page Objects.
Exists only for the duration of UTAM pilot.

- to generate page objects 
```bash
yarn compile
```

- to publish artifact
```bash
cd utam-preview
npm login
npm npm publish --access public
```

- to preview published artifact
```bash
npm pack
```
from aws_allowlister.command import generate
